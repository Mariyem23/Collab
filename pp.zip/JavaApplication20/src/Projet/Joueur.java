
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projet;

import java.util.ArrayList;

/**
 *
 * @author mariyem
 */


public class Joueur {
    private String nom;
    private ArrayList<Pions> pions;
    private boolean vivant; // Indique si le joueur est encore vivant

    public Joueur(String nom) {
        this.nom = nom;
        this.pions = new ArrayList<>();
        this.vivant = true; // Par défaut, un joueur est vivant à sa création
    }

    // Getters et Setters
    public String getNom() {
        return nom;
    }

    public ArrayList<Pions> getPions() {
        return pions;
    }

    public boolean estVivant() {
        return vivant;
    }

    public void setVivant(boolean vivant) {
        this.vivant = vivant;
    }

    public void ajouterPion(Pions pion) {
        pions.add(pion);
    }
}

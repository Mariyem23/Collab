package Projet;

import java.util.ArrayList;
import java.util.Collections;

public class TuilesTombales {

    private ArrayList<Tuile> tuiles;

    // Constructeur de TuilesTombales
    public TuilesTombales() {
        tuiles = new ArrayList<>();
        initialiserTuiles(); // Appel pour initialiser les tuiles
    }

    /**
     * Initialise les tuiles avec leurs types et valeurs.
     */
    private void initialiserTuiles() {
        // Ajout des tuiles de déplacement
        tuiles.add(new Tuile("Déplacement", "5 pas"));
        tuiles.add(new Tuile("Déplacement", "7 pas"));
        tuiles.add(new Tuile("Déplacement", "7 pas"));
        tuiles.add(new Tuile("Déplacement", "8 pas"));
        tuiles.add(new Tuile("Déplacement", "8 pas"));
        tuiles.add(new Tuile("Déplacement", "10 pas"));

        // Ajout des tuiles spéciales
        tuiles.add(new Tuile("Spéciale", "une proie"));
        tuiles.add(new Tuile("Spéciale", "deux proies"));

        // Mélange des tuiles pour un ordre aléatoire
        Collections.shuffle(tuiles);
    }

    /**
     * Permet de piocher une tuile et la replace à la fin pour la réutiliser.
     *
     * @return La tuile piochée.
     */
    public Tuile piocherTuile() {
        if (tuiles.isEmpty()) {
            System.out.println("Aucune tuile disponible !");
            return null;
        }

        Tuile tuile = tuiles.remove(0); // Retirer la première tuile
        tuiles.add(tuile); // La replacer à la fin
        return tuile;
    }

    /**
     * Affiche toutes les tuiles restantes.
     */
    public void afficherTuiles() {
        System.out.println("Tuiles disponibles :");
        for (Tuile tuile : tuiles) {
            System.out.println("- " + tuile);
        }
    }

    public boolean estPileVide() {
        return tuiles.isEmpty();
    }

    public void reinitialiserPile() {
        Collections.shuffle(tuiles);
    }

    /**
     * Représente une tuile avec un type et une valeur.
     */
    public class Tuile {

        private String type;  // Type de tuile : "Déplacement" ou "Spéciale"
        private String valeur; // Valeur associée (ex : "5 pas" ou "une proie")

        // Constructeur de Tuile
        public Tuile(String type, String valeur) {
            this.type = type;
            this.valeur = valeur;
        }

        public String getType() {
            return type;
        }

        public String getValeur() {
            return valeur;
        }

        @Override
        public String toString() {
            return valeur + " (" + type + ")";
        }
    }
}

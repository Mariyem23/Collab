/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projet;

/**
 *
 * @author hadda
 */
public class BlocDePierre extends Elements {

    // Constructeur                         
    public BlocDePierre(int x, int y) {
        super(x, y, "BlocDePierre");
    }

    @Override
    public String toString() {
        return "BlocDePierre{" + "x=" + getX() + ", y=" + getY() + '}';
    }

    /**
     * Vérifie si un joueur pousse le bloc et effectue le déplacement.
     *
     * @param direction Direction du déplacement ("haut", "bas", "gauche",
     * "droite").
     * @param plateau Le plateau de jeu.
     * @param joueur Le pion joueur qui pousse la pierre.
     * @return True si le bloc a été poussé avec succès, False sinon.
     */
    public boolean deplacerSiPousse(String direction, Plateau plateau, Pions joueur) {
        // Vérifie si le joueur est adjacent au bloc
        if (!estAdjacent(joueur)) {
            return false; // Le joueur n'est pas à côté du bloc
        }

        int nouvelleX = this.getX();
        int nouvelleY = this.getY();

        // Calcul des nouvelles coordonnées selon la direction
        switch (direction.toLowerCase()) {
            case "haut" ->
                nouvelleX -= 1;
            case "bas" ->
                nouvelleX += 1;
            case "gauche" ->
                nouvelleY -= 1;
            case "droite" ->
                nouvelleY += 1;
            default -> {
                return false; // Direction invalide
            }
        }

        // Vérifie que la nouvelle position est valide
        if (!plateau.estPositionValide(nouvelleX, nouvelleY)) {
            return false; // La position cible est hors plateau
        }

        Case caseDestination = plateau.getCase(nouvelleX, nouvelleY);

        // Vérifie que la case destination est accessible et non occupée
        if (caseDestination.estAccessible() && !caseDestination.estOccupee()) {
            // Déplace le bloc
            plateau.getCase(this.getX(), this.getY()).setContenu(null); // Retirer de l'ancienne case
            this.setPosition(nouvelleX, nouvelleY);
            caseDestination.setContenu(this); // Placer dans la nouvelle case

            // verifie si le bloc est hors du plateau apres le deplacement 
            supprimerSiHorsPlateau(plateau);

            return true;
        }

        return false; // Si la case destination est occupée ou inaccessible
    }

    /**
     * Vérifie si le bloc est adjacent à un pion joueur.
     *
     * @param joueur Le pion joueur.
     * @return True si le joueur est adjacent au bloc, False sinon.
     */
    public boolean estAdjacent(Pions joueur) {
        int joueurX = joueur.getX();
        int joueurY = joueur.getY();

        int blocX = this.getX();
        int blocY = this.getY();

        // Vérifie les cases adjacentes (haut, bas, gauche, droite)
        return (joueurX == blocX - 1 && joueurY == blocY)
                || // Haut
                (joueurX == blocX + 1 && joueurY == blocY)
                || // Bas
                (joueurX == blocX && joueurY == blocY - 1)
                || // Gauche
                (joueurX == blocX && joueurY == blocY + 1);   // Droite
    }

    /**
     * Supprime le bloc si poussé en dehors du plateau (cas des cases d'entrée
     * ou sortie).
     *
     * @param plateau Plateau de jeu.
     * @return True si le bloc a été supprimé, False sinon.
     */
    public boolean supprimerSiHorsPlateau(Plateau plateau) {
        int x = this.getX();
        int y = this.getY();

        // Vérifie si la case est une case d'entrée ou de sortie
        Case caseActuelle = plateau.getCase(x, y);
        if (caseActuelle != null && (caseActuelle.estCaseEntree(plateau.getLignes(), plateau.getColonnes()) || caseActuelle.estCaseSortie())) {
            caseActuelle.setContenu(null); // Supprimer du plateau
            System.out.println("Bloc de pierre supprimé car hors du plateau ou sur une case spéciale.");
            return true;
        }

        return false;
    }

}

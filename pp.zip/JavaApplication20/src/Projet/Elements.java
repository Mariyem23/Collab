/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projet;

/**
 *
 * @author hadda
 */

public abstract class Elements {
    private int x;
    private int y;
    private String type; // Type d'élément (e.g., "BlocDePierre", "FlaqueHemoglobine")

    public Elements(int x, int y, String type) {
        this.x = x;
        this.y = y;
        this.type = type;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public String getType() {
        return type;
    }

    public boolean estBlocDePierre() {
        return this instanceof BlocDePierre;
    }
}



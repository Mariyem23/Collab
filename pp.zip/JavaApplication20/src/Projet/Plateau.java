/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

ALT + inser (peut etre FN en plus) pour les getter + setters + ...
Ctrl + ESPACE si les y a pas les truc de tout qui s'    affiche quand je fais var. 
 */
package Projet;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author hadda
 */
public class Plateau {

    private Case[][] grille;
    private int lignes;
    private int colonnes;

    // Constructeur
    public Plateau(int lignes, int colonnes) {
        this.lignes = lignes;
        this.colonnes = colonnes;
        grille = new Case[lignes][colonnes];
        initialiserPlateau();
        definirZonesInaccessibles();
    }

    // Initialise la grille avec des cases accessibles par défaut
    private void initialiserPlateau() {
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                grille[i][j] = new Case(i, j, true); // Toutes les cases accessibles au départ
            }
        }
    }

    // Définit les zones inaccessibles sur le plateau
    private void definirZonesInaccessibles() {
        int[][] zonesInaccessibles = {
            {0, 12}, {0, 13}, {0, 14}, {0, 15},
            {1, 13}, {1, 14}, {1, 15},
            {2, 14}, {2, 15},
            {3, 15},
            {7, 0},
            {8, 0}, {8, 1},
            {9, 0}, {9, 1}, {9, 2},
            {10, 0}, {10, 1}, {10, 2}, {10, 3}
        };

        for (int[] zone : zonesInaccessibles) {
            int x = zone[0];
            int y = zone[1];
            if (x >= 0 && x < lignes && y >= 0 && y < colonnes) {
                grille[x][y].setAccessible(false);
            }
        }
    }

    // verifie si une position est valide 
    public boolean estPositionValide(int x, int y) {
        return x >= 0 && y >= 0 && x < lignes && y < colonnes && grille[x][y].estAccessible();
    }

    public Case getCase(int x, int y) {
        if (estPositionValide(x, y)) {
            return grille[x][y];
        }
        return null;
    }

    public void afficherPlateau() {
        for (int i = 0; i < lignes; i++) {
            for (int j = 0; j < colonnes; j++) {
                Case c = grille[i][j];
                if (!c.estAccessible()) {
                    System.out.print("[X]"); // Zone inaccessible
                } else if (c.getContenu() instanceof BlocDePierre) {
                    System.out.print("[B]"); // Bloc de pierre
                } else if (c.getContenu() instanceof Pions) {
                    System.out.print("[P]"); // Pion
                } else if ("[T]".equals(c.getContenu())) {
                    System.out.print("[T]"); // Indique la traversée
                } else {
                    System.out.print("[ ]"); // Case vide
                }
            }
            System.out.println();
        }
    }

    // Déplace un bloc vers une nouvelle position
    public boolean deplacerBloc(BlocDePierre bloc, int nouvelleX, int nouvelleY) {
        // Vérifie si la nouvelle position est valide
        if (estCaseLibre(nouvelleX, nouvelleY)) {
            // Supprime le bloc de sa case actuelle
            Case ancienneCase = getCase(bloc.getX(), bloc.getY());
            if (ancienneCase != null) {
                ancienneCase.setContenu(null);
            }

            // Met à jour la position du bloc
            bloc.setPosition(nouvelleX, nouvelleY);

            // Place le bloc dans la nouvelle case
            Case nouvelleCase = getCase(nouvelleX, nouvelleY);
            if (nouvelleCase != null) {
                nouvelleCase.setContenu(bloc);
            }

            return true; // Déplacement réussi
        }
        return false; // Déplacement impossible
    }

// Vérifie si une case est libre (accessible et non occupée)
    public boolean estCaseLibre(int x, int y) {
        if (!estPositionValide(x, y)) {
            return false; // La position est invalide
        }

        Case caseCible = getCase(x, y);
        return caseCible != null && caseCible.estAccessible() && !caseCible.estOccupee();
    }

// Fait glisser un bloc sur une flaque d'hémoglobine
    public void glisserBlocSurFlaque(BlocDePierre bloc, int directionX, int directionY) {
        int x = bloc.getX();
        int y = bloc.getY();

        while (estCaseLibre(x + directionX, y + directionY)) {
            x += directionX;
            y += directionY;
        }

        // Met à jour la position du bloc
        deplacerBloc(bloc, x, y);
    }
// Le monstre pousse un bloc dans une direction donnée

    public void pousserBlocParMonstre(BlocDePierre bloc, int directionX, int directionY) {
        int nouvelleX = bloc.getX() + directionX;
        int nouvelleY = bloc.getY() + directionY;

        // Vérifie si le bloc peut être poussé
        if (estCaseLibre(nouvelleX, nouvelleY)) {
            deplacerBloc(bloc, nouvelleX, nouvelleY);
        } else {
            // Si le bloc est poussé hors du plateau, il est supprimé
            Case caseDestination = getCase(nouvelleX, nouvelleY);
            if (caseDestination == null || caseDestination.estCaseSortie()) {
                Case caseActuelle = getCase(bloc.getX(), bloc.getY());
                if (caseActuelle != null) {
                    caseActuelle.setContenu(null); // Supprime le bloc de la case actuelle
                }
                System.out.println("Le monstre a poussé un bloc hors du plateau.");
            }
        }
    }
// Vérifie si un bloc est sur une position finale interdite (entrée ou sortie)

    public boolean verifierBlocPositionInterdite(BlocDePierre bloc) {
        Case caseActuelle = getCase(bloc.getX(), bloc.getY());
        if (caseActuelle != null && (caseActuelle.estCaseEntree(lignes, colonnes) || caseActuelle.estCaseSortie())) {
            // Supprime le bloc si nécessaire
            caseActuelle.setContenu(null);
            System.out.println("Bloc de pierre retiré car il est sur une position interdite.");
            return true;
        }
        return false;
    }
// Retourne les blocs voisins d'une case donnée

    public List<BlocDePierre> recupererBlocsVoisins(int x, int y) {
        List<BlocDePierre> blocsVoisins = new ArrayList<>();
        int[][] directions = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}}; // Haut, Bas, Gauche, Droite

        for (int[] direction : directions) {
            int voisinX = x + direction[0];
            int voisinY = y + direction[1];
            Case voisin = getCase(voisinX, voisinY);
            if (voisin != null && voisin.getContenu() instanceof BlocDePierre) {
                blocsVoisins.add((BlocDePierre) voisin.getContenu());
            }
        }
        return blocsVoisins;
    }
// Gère une glissade de blocs en chaîne

    public void gererGlissadeChaine(BlocDePierre bloc, int directionX, int directionY) {
        int x = bloc.getX();
        int y = bloc.getY();

        while (estCaseLibre(x + directionX, y + directionY)) {
            Case caseSuivante = getCase(x + directionX, y + directionY);
            if (caseSuivante != null && caseSuivante.getContenu() instanceof BlocDePierre) {
                BlocDePierre blocSuivant = (BlocDePierre) caseSuivante.getContenu();
                gererGlissadeChaine(blocSuivant, directionX, directionY); // Appel récursif pour pousser le bloc suivant
            }
            x += directionX;
            y += directionY;
        }

        // Déplace le bloc actuel
        deplacerBloc(bloc, x, y);
    }
// Place plusieurs blocs de pierre sur le plateau

    public void initialiserBlocs(List<int[]> positions) {
        for (int[] position : positions) {
            int x = position[0];
            int y = position[1];
            if (estCaseLibre(x, y)) {
                BlocDePierre bloc = new BlocDePierre(x, y);
                getCase(x, y).setContenu(bloc);
            } else {
                System.out.println("Impossible de placer un bloc à la position : (" + x + ", " + y + ")");
            }
        }
    }
// Supprime un bloc de pierre du plateau

    public void supprimerBloc(BlocDePierre bloc) {
        Case caseActuelle = getCase(bloc.getX(), bloc.getY());
        if (caseActuelle != null) {
            caseActuelle.setContenu(null);
            System.out.println("Bloc de pierre supprimé de la position : (" + bloc.getX() + ", " + bloc.getY() + ")");
        }
    }

    public int getLignes() {
        return lignes;
    }

    public int getColonnes() {
        return colonnes;
    }

    // Marque le passage d'un pion sur une case occupée
    public void marquerPassage(int x, int y) {
        Case casePassage = getCase(x, y);
        if (casePassage != null) {
            System.out.println("Le pion passe sur la case (" + x + ", " + y + ") !");
            casePassage.setContenu("[T]"); // T pour 'Traverse'
            afficherPlateau(); // Affiche le plateau mis à jour
            casePassage.setContenu(null); // Retire la marque après l'affichage
        }
    }

}

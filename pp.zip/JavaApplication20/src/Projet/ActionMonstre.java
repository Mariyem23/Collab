/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projet;

/**
 *
 * @author hadda
 */


public class ActionMonstre {
    private Monstre monstre;
    private Plateau plateau;
    private TuilesTombales tuilesTombales;

    // Constructeur
    public ActionMonstre(Monstre monstre, Plateau plateau, TuilesTombales tuilesTombales) {
        this.monstre = monstre;
        this.plateau = plateau;
        this.tuilesTombales = tuilesTombales;
    }

    /**
     * Gère le déplacement complet du monstre selon les règles.
     */
    public void deplacerMonstre() {
        TuilesTombales.Tuile tuile = tuilesTombales.piocherTuile();
        if (tuile == null) {
            System.out.println("Pas de tuile disponible pour déplacer le monstre.");
            return;
        }

        System.out.println("Tuile piochée : " + tuile);

        if (tuile.getType().equals("Déplacement")) {
            int nombreDePas = Integer.parseInt(tuile.getValeur().split(" ")[0]);
            deplacerSurDistance(nombreDePas);
        } else if (tuile.getType().equals("Spéciale")) {
            gererTuileSpeciale(tuile);
        }
    }

    /**
     * Déplace le monstre sur une certaine distance, case par case.
     */
    private void deplacerSurDistance(int distance) {
        for (int i = 0; i < distance; i++) {
            // Vérifier les proies visibles avant d'avancer
            Pions cible = chercherProieVisible();
            if (cible != null) {
                monstre.tournerVers(cible);
            }

            avancerMonstre();

            mangerPionSiPresent();
        }
    }

    /**
     * Gère les tuiles spéciales comme "une proie" ou "deux proies".
     */
    private void gererTuileSpeciale(TuilesTombales.Tuile tuile) {
        int nombreDeProies = tuile.getValeur().equals("une proie") ? 1 : 2;

        for (int i = 0; i < nombreDeProies; i++) {
            Pions cible = chercherProieVisible();
            if (cible != null) {
                monstre.tournerVers(cible);
            }

            avancerMonstre();

            mangerPionSiPresent();
        }
    }

    /**
     * Avance le monstre d'une case dans sa direction actuelle.
     */
    private void avancerMonstre() {
        int x = monstre.getPositionX();
        int y = monstre.getPositionY();

        switch (monstre.getOrientation()) {
            case "haut" -> x--;
            case "bas" -> x++;
            case "gauche" -> y--;
            case "droite" -> y++;
        }

        if (plateau.estPositionValide(x, y)) {
            plateau.getCase(monstre.getPositionX(), monstre.getPositionY()).setContenu(null);
            monstre.setPosition(x, y);
            plateau.getCase(x, y).setContenu(monstre);
            System.out.println("Le monstre avance vers " + monstre.getOrientation());
        } else {
            System.out.println("Le monstre ne peut pas avancer : position invalide.");
        }
    }

    /**
     * Vérifie si un pion est sur la case actuelle et le dévore.
     */
    private void mangerPionSiPresent() {
        Case caseCourante = plateau.getCase(monstre.getPositionX(), monstre.getPositionY());
        if (caseCourante != null && caseCourante.contientPion()) {
            Pions pion = (Pions) caseCourante.getContenu();
            System.out.println("Le monstre dévore un pion de couleur : " + pion.getCouleur());
            caseCourante.setContenu(null); // Retirer le pion
        }
    }

    /**
     * Cherche une proie visible dans les directions avant, gauche ou droite.
     * @return Le pion visible ou null si aucune proie n'est visible.
     */
    private Pions chercherProieVisible() {
        int x = monstre.getPositionX();
        int y = monstre.getPositionY();

        // Directions à vérifier (avant, gauche, droite)
        int[][] directions = switch (monstre.getOrientation()) {
            case "haut" -> new int[][]{{-1, 0}, {0, -1}, {0, 1}};
            case "bas" -> new int[][]{{1, 0}, {0, 1}, {0, -1}};
            case "gauche" -> new int[][]{{0, -1}, {-1, 0}, {1, 0}};
            case "droite" -> new int[][]{{0, 1}, {1, 0}, {-1, 0}};
            default -> new int[0][0];
        };

        for (int[] dir : directions) {
            int dx = dir[0];
            int dy = dir[1];
            int nx = x + dx;
            int ny = y + dy;

            if (plateau.estPositionValide(nx, ny)) {
                Case caseVerifiee = plateau.getCase(nx, ny);
                if (caseVerifiee != null && caseVerifiee.contientPion()) {
                    return (Pions) caseVerifiee.getContenu();
                }
            }
        }

        return null;
    }
}

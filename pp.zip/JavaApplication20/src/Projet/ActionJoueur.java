/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projet;

/**
 *
 * @author haddad
 */
public class ActionJoueur {

    private Joueur joueur;
    private Plateau plateau;

    public ActionJoueur(Joueur joueur, Plateau plateau) {
        this.joueur = joueur;
        this.plateau = plateau;
    }

    /**
     * Déplace un pion tout en respectant les règles.
     */
    public boolean deplacerPion(Pions pion, String direction) {
        if (!joueur.getPions().contains(pion)) {
            System.out.println("Erreur : ce pion n'appartient pas au joueur " + joueur.getNom() + " !");
            return false;
        }

        int x = pion.getX();
        int y = pion.getY();
        int nouvelleX = x;
        int nouvelleY = y;

        // Calcul de la nouvelle position en fonction de la direction
        switch (direction.toLowerCase()) {
            case "haut" ->
                nouvelleX -= 1;
            case "bas" ->
                nouvelleX += 1;
            case "gauche" ->
                nouvelleY -= 1;
            case "droite" ->
                nouvelleY += 1;
            default -> {
                System.out.println("Direction invalide !");
                return false;
            }
        }

        // Vérification de la validité de la position
        if (!plateau.estPositionValide(nouvelleX, nouvelleY)) {
            System.out.println("Erreur : la case cible est hors plateau !");
            return false;
        }

        Case caseDestination = plateau.getCase(nouvelleX, nouvelleY);

        // Vérification si la case est occupée par un pion
        if (caseDestination.estOccupee() && caseDestination.contientPion()) {
            if (pion.getDepla() < 2) {
                System.out.println("Pas assez de mouvements pour traverser une case occupee !");
                return false;
            } else {
                System.out.println("Le pion traverse une case occupee !");
                plateau.marquerPassage(x, y); // Marquer le passage
            }
        }

        // Déplacement effectif
        plateau.getCase(x, y).setContenu(null); // Vide l'ancienne case
        pion.setPosition(nouvelleX, nouvelleY); // Met à jour la position
        caseDestination.setContenu(pion); // Place le pion sur la nouvelle case
        pion.setDepla(pion.getDepla() - 1); // Réduit la capacité de mouvement
        return true;
    }

}

package Projet;

/**
 *
 * @author hadda
 */
public class FlaqueHemoglobine extends Elements {

    public FlaqueHemoglobine(int x, int y) {
        super(x, y, "FlaqueHemoglobine");
    }

    public boolean gererGlissade(int dx, int dy, Plateau plateau, Pions pion) {
        int xActuel = getX();
        int yActuel = getY();
        boolean dp = true;

        if (pion.getDepla() <= 1) {
            dp = false;
        }

        while (dp) {
            int xSuivant = xActuel + dx;
            int ySuivant = yActuel + dy;

            // Vérifie si la prochaine position est valide
            if (!plateau.estPositionValide(xSuivant, ySuivant)) {
                System.out.println("Glissade arrêtée : hors plateau.");
                break; // Arrête la glissade si hors plateau
            }

            Case caseSuivante = plateau.getCase(xSuivant, ySuivant);

            // Si la case suivante est occupée
            if (pion.getDepla() <= 2) {
                dp = false;
            }
            while (dp) {
                if (caseSuivante.estOccupee()) {
                    Object obstacle = caseSuivante.getContenu();

                    if (obstacle instanceof BlocDePierre) {
                        BlocDePierre bloc = (BlocDePierre) obstacle;
                        String direction = determinerDirection(dx, dy);
                        if (!bloc.deplacerSiPousse(direction, plateau, null)) {
                            System.out.println("Glissade arrêtée : bloc de pierre bloqué.");
                            return false; // La glissade s'arrête si le bloc ne peut pas bouger
                        }
                    } else {
                        System.out.println("Glissade arrêtée : obstacle immobile détecté.");
                        return false; // La glissade s'arrête à cause d'un obstacle immobile
                    }
                }
            }

            // Déplace le contenu (pion ou bloc) sur la case suivante
            plateau.getCase(xActuel, yActuel).setContenu(null); // Vide l'ancienne case
            caseSuivante.setContenu(pion);
            pion.setPosition(xSuivant, ySuivant);
            pion.setDepla(pion.getDepla() - 1);
            // Met à jour les coordonnées actuelles
            xActuel = xSuivant;
            yActuel = ySuivant;
        }

        System.out.println("Glissade terminée avec succès.");
        return true; // Glissade terminée
    }

// Méthode utilitaire pour déterminer la direction à partir de dx et dy
    private String determinerDirection(int dx, int dy) {
        if (dx == -1) {
            return "haut";
        }
        if (dx == 1) {
            return "bas";
        }
        if (dy == -1) {
            return "gauche";
        }
        if (dy == 1) {
            return "droite";
        }
        return null; // Cas impossible
    }

    public boolean peutEtreDeplace() {
        return false; // Les flaques ne peuvent pas être déplacées
    }
}

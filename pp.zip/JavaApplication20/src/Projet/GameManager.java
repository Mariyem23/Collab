// GameManager.java
package Projet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class GameManager {

    private Plateau plateau;
    private ArrayList<Joueur> joueurs;
    private Monstre monstre;
    private TuilesTombales tuilesTombales;
    private boolean partieTerminee;
    private int manche;

    // Représentation des pions par couleurs
    private static final HashMap<String, int[][]> PIONS_PAR_COULEUR = new HashMap<>();

    static {
        PIONS_PAR_COULEUR.put("Rouge", new int[][]{{1, 6}, {2, 5}, {3, 4}, {4, 3}});
        PIONS_PAR_COULEUR.put("Bleu", new int[][]{{1, 6}, {2, 5}, {3, 4}, {4, 3}});
        PIONS_PAR_COULEUR.put("Jaune", new int[][]{{1, 6}, {2, 5}, {3, 4}, {4, 3}});
        PIONS_PAR_COULEUR.put("Vert", new int[][]{{1, 6}, {2, 5}, {3, 4}, {4, 3}});
        PIONS_PAR_COULEUR.put("Violet", new int[][]{{1, 6}, {3, 4}, {5, 2}});
        PIONS_PAR_COULEUR.put("Noir", new int[][]{{1, 6}, {3, 4}, {5, 2}});
        PIONS_PAR_COULEUR.put("Blanc", new int[][]{{1, 6}, {3, 4}, {5, 2}});
    }

    public GameManager(int nbJoueurs, ArrayList<String> couleursDisponibles) {
        this.plateau = new Plateau(11, 16); // Plateau de 11x16
        this.joueurs = new ArrayList<>();
        this.tuilesTombales = new TuilesTombales();
        this.monstre = new Monstre(10, 15, "haut"); // Monstre placé sur la case de sortie (10,15)
        this.partieTerminee = false;
        this.manche = 1;

        plateau.afficherPlateau(); // Afficher le plateau dès le début
        initialiserJoueurs(nbJoueurs, couleursDisponibles);
    }

    private void initialiserJoueurs(int nbJoueurs, ArrayList<String> couleursDisponibles) {
        Scanner scanner = new Scanner(System.in);
        for (int i = 1; i <= nbJoueurs; i++) {
            Joueur joueur = new Joueur("Joueur " + i);
            joueurs.add(joueur);

            System.out.println(joueur.getNom() + ", quelle couleur voulez-vous jouer ?");
            couleursDisponibles.forEach(System.out::println); // Affiche les couleurs restantes
            String couleur = scanner.next();

            // Verifie si la couleur est valide et la retire de la liste
            while (!couleursDisponibles.contains(couleur)) {
                System.out.println("Couleur invalide. Veuillez choisir parmi les options disponibles.");
                couleur = scanner.next();
            }

            couleursDisponibles.remove(couleur); // Supprime la couleur choisie pour eviter les doublons
            System.out.println("Couleur " + couleur + " attribuee a " + joueur.getNom());

            // Utilisation de l'instruction if-else à la place de l'opérateur ternaire
            int maxPions;
            if (nbJoueurs > 4) {
                maxPions = 3;
            } else {
                maxPions = 4;
            }

            placerPionsPourJoueur(joueur, couleur, scanner, maxPions);
        }
        plateau.afficherPlateau(); // Affiche le plateau apres le placement des pions
    }

    private void placerPionsPourJoueur(Joueur joueur, String couleur, Scanner scanner, int maxPions) {
        System.out.println(joueur.getNom() + ", vos " + maxPions + " pions seront places a la position de depart (0, 0).");
        int[][] valeursPions = PIONS_PAR_COULEUR.get(couleur);

        for (int i = 0; i < maxPions; i++) {
            int valeurRecto = valeursPions[i][0];
            int valeurVerso = valeursPions[i][1];

            // Cree le pion avec les valeurs recto/verso et positionne-le a (0, 0)
            Pions pion = new Pions(couleur, new int[]{valeurRecto, valeurVerso}, 0, 0);
            joueur.ajouterPion(pion);
            plateau.getCase(0, 0).setContenu(pion);

            System.out.println("Pion " + couleur + valeurRecto + " (valeur recto: " + valeurRecto + ", verso: " + valeurVerso + ") place a (0, 0).");

            // Placement avec des mouvements
            int mouvementsRestants = valeurRecto;
            System.out.println("Deplacez le pion en suivant la direction (haut, bas, gauche, droite). Faites " + mouvementsRestants + " mouvements.");

            while (mouvementsRestants > 0) {
                System.out.println("Mouvements restants : " + mouvementsRestants);
                String direction = scanner.next();

                // Calcul de la nouvelle position
                int nouvelleX = pion.getX();
                int nouvelleY = pion.getY();

                switch (direction.toLowerCase()) {
                    case "haut" ->
                        nouvelleX -= 1;
                    case "bas" ->
                        nouvelleX += 1;
                    case "gauche" ->
                        nouvelleY -= 1;
                    case "droite" ->
                        nouvelleY += 1;
                    default -> {
                        System.out.println("Direction invalide !");
                        continue;
                    }
                }

                // Verification de la validite de la case cible
                if (!plateau.estPositionValide(nouvelleX, nouvelleY) || !plateau.estCaseLibre(nouvelleX, nouvelleY)) {
                    System.out.println("Case invalide. Reessayez.");
                    continue;
                }

                // Deplacement effectif
                plateau.getCase(pion.getX(), pion.getY()).setContenu(null); // Vide la case actuelle
                pion.setPosition(nouvelleX, nouvelleY); // Met a jour la position du pion
                plateau.getCase(nouvelleX, nouvelleY).setContenu(pion); // Place le pion sur la nouvelle case
                plateau.afficherPlateau();

                mouvementsRestants--;
            }
        }
    }

    public void jouer() {
        Scanner scanner = new Scanner(System.in);

        while (!partieTerminee) {
            System.out.println("Debut de la manche " + manche);

            for (Joueur joueur : joueurs) {
                if (joueur.estVivant()) {
                    System.out.println(joueur.getNom() + ", c'est a votre tour.");
                    ActionJoueur actionJoueur = new ActionJoueur(joueur, plateau);
                    for (Pions pion : joueur.getPions()) {
                        if (pion.getDepla() > 0) {
                            System.out.println("Deplacer le pion de valeur visible : " + pion.getValeurVisible());
                            System.out.println("Entrez la sequence de deplacements (par ex. haut,haut,droite) :");
                            String[] mouvements = scanner.next().split(",");

                            if (mouvements.length != pion.getValeurVisible()) {
                                System.out.println("Erreur : le nombre de mouvements doit correspondre exactement a la valeur visible du pion.");
                                continue;
                            }

                            boolean deplacementValide = true;
                            for (String direction : mouvements) {
                                if (!actionJoueur.deplacerPion(pion, direction)) {
                                    deplacementValide = false;
                                    break;
                                }
                                plateau.afficherPlateau(); // Afficher le plateau après chaque pas
                            }

                            if (deplacementValide) {
                                pion.retourner();
                            } else {
                                System.out.println("Deplacement interrompu, le pion reste en place.");
                            }
                        } else {
                            System.out.println("Pion avec valeur 0, impossible a deplacer ce tour.");
                        }
                    }
                }
            }

            System.out.println("Tour du monstre.");
            ActionMonstre actionMonstre = new ActionMonstre(monstre, plateau, tuilesTombales);
            actionMonstre.deplacerMonstre();
            plateau.afficherPlateau(); // Afficher le plateau après le tour du monstre

            verifierConditionsFin();
            if (!partieTerminee && tuilesTombales.estPileVide()) {
                passerALaMancheSuivante();
            }
        }

        System.out.println("La partie est terminee !");
    }

    private void verifierConditionsFin() {
        boolean tousLesJoueursElimines = true;
        for (Joueur joueur : joueurs) {
            if (!joueur.getPions().isEmpty()) {
                tousLesJoueursElimines = false;
                break;
            }
        }

        boolean finDeMancheDeux = manche == 2 && tuilesTombales.estPileVide();

        partieTerminee = tousLesJoueursElimines || finDeMancheDeux;
    }

    private void passerALaMancheSuivante() {
        System.out.println("Fin de la manche 1. Debut de la manche 2.");
        manche = 2;
        tuilesTombales.reinitialiserPile();
    }

    public Plateau getPlateau() {
        return plateau;
    }

    public ArrayList<Joueur> getJoueurs() {
        return joueurs;
    }
}

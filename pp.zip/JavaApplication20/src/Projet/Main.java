/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Projet;

/**
 *
 * @author hadda
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Bienvenue dans Finstere Flure !");
        int nbJoueurs = 0;

        // Validation stricte pour le nombre de joueurs
        while (nbJoueurs < 2 || nbJoueurs > 7) {
            System.out.print("Combien de joueurs ? (2 a 7) : ");
            if (scanner.hasNextInt()) {
                nbJoueurs = scanner.nextInt();
                if (nbJoueurs < 2 || nbJoueurs > 7) {
                    System.out.println("Veuillez entrer un nombre entre 2 et 7.");
                }
            } else {
                System.out.println("Entree invalide. Veuillez entrer un nombre.");
                scanner.next(); // Consomme l'entrée invalide
            }
        }

        // Restreindre les couleurs disponibles
        ArrayList<String> couleursDisponibles = new ArrayList<>();
        if (nbJoueurs <= 4) {
            couleursDisponibles.add("Rouge");
            couleursDisponibles.add("Bleu");
            couleursDisponibles.add("Jaune");
            couleursDisponibles.add("Vert");
        } else {
            couleursDisponibles.add("Rouge");
            couleursDisponibles.add("Bleu");
            couleursDisponibles.add("Jaune");
            couleursDisponibles.add("Vert");
            couleursDisponibles.add("Violet");
            couleursDisponibles.add("Noir");
            couleursDisponibles.add("Blanc");
        }

        // Initialisation de GameManager avec restrictions
        GameManager gameManager = new GameManager(nbJoueurs, couleursDisponibles);
        gameManager.jouer();
    }
}

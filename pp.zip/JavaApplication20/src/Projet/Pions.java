/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Projet;

/**
 *
 * @author Utilisateur
 */
public class Pions extends Elements {

    private String couleur;
    private int valeurFaceRecto;
    private int valeurFaceVerso;
    private boolean estRectoVisible;
    private boolean estSorti;
    private int depla;

    // Nouveau constructeur
    public Pions(String couleur, int[] valeurs, int x, int y) {
        super(x, y, "Pion");
        this.couleur = couleur;
        this.valeurFaceRecto = valeurs[0];
        this.valeurFaceVerso = valeurs[1];
        this.estRectoVisible = true;
        this.estSorti = false;
        this.depla = valeurFaceRecto; // Initialisation à la valeur de la face recto
    }

    // Getters et Setters
    public String getCouleur() {
        return couleur;
    }

    public int getValeurVisible() {
        return estRectoVisible ? valeurFaceRecto : valeurFaceVerso;
    }

    public int getDepla() {
        return depla;
    }

    public void setDepla(int depla) {
        if (depla >= 0) {
            this.depla = depla;
        } else {
            System.out.println("Erreur : la valeur de déplacement ne peut pas être négative.");
        }
    }

    public boolean estSorti() {
        return estSorti;
    }

    public void setSorti(boolean sorti) {
        this.estSorti = sorti;
    }

    // Retourner le pion
    public void retourner() {
        estRectoVisible = !estRectoVisible;
        depla = getValeurVisible(); // Met à jour la valeur de déplacement
        System.out.println("Le pion " + couleur + " est retourné. Nouvelle valeur visible : " + getValeurVisible());
    }

    // Déplacement du pion
    public void deplacer(int dx, int dy, Plateau plateau) {
        if (depla <= 0) {
            System.out.println("Le pion " + couleur + " ne peut plus bouger pour ce tour.");
            retourner(); // Retourner la face
            return;
        }

        int nouvelleX = getX() + dx;
        int nouvelleY = getY() + dy;

        // Vérification de la validité de la position
        if (!plateau.estPositionValide(nouvelleX, nouvelleY)) {
            System.out.println("Déplacement invalide : hors plateau !");
            return;
        }

        Case caseDestination = plateau.getCase(nouvelleX, nouvelleY);

        // Si la case est occupée par un autre pion
        if (caseDestination.estOccupee() && caseDestination.contientPion()) {
            if (depla < 2) {
                System.out.println("Pas assez de mouvements pour traverser une case occupée !");
                return;
            } else {
                System.out.println("Le pion " + couleur + " traverse une case occupée par un autre pion.");
                plateau.marquerPassage(getX(), getY()); // Marquer graphiquement le passage
            }
        }

        // Déplacement effectif
        plateau.getCase(getX(), getY()).setContenu(null); // Vide l'ancienne case
        setPosition(nouvelleX, nouvelleY);
        caseDestination.setContenu(this); // Place le pion sur la nouvelle case
        depla--; // Réduit la capacité de mouvement
        verifierSiSorti(plateau); // Vérifie si le pion est sorti
    }

    // Vérifier si le pion est sorti
    public boolean verifierSiSorti(Plateau plateau) {
        Case caseActuelle = plateau.getCase(getX(), getY());
        if (caseActuelle != null && caseActuelle.estCaseSortie()) {
            estSorti = true;
            System.out.println("Le pion " + couleur + " est sorti !");
            return true;
        }
        return false;
    }

    // Détermine la direction en fonction des coordonnées
    private String determinerDirection(int dx, int dy) {
        if (dx == -1) {
            return "haut";
        }
        if (dx == 1) {
            return "bas";
        }
        if (dy == -1) {
            return "gauche";
        }
        if (dy == 1) {
            return "droite";
        }
        return "inconnue"; // Cas impossible
    }
}

package Projet;

/**
 *
 * @author hadda
 */
public class Case {
    private int x; // Coordonnée x
    private int y; // Coordonnée y
    private boolean accessible; // Si la case est accessible ou non
    private Object contenu; // Un seul élément peut être présent sur la case (Bloc, Pion, etc.)

    // Constructeur
    public Case(int x, int y, boolean accessible) {
        this.x = x;
        this.y = y;
        this.accessible = accessible;
        this.contenu = null; // Case vide au départ
    }

    // GETTERS & SETTERS
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public boolean estAccessible() {
        return accessible;
    }

    public void setAccessible(boolean accessible) {
        this.accessible = accessible;
    }

    public Object getContenu() {
        return contenu;
    }

    public void setContenu(Object contenu) {
        this.contenu = contenu;
    }

    public boolean estOccupee() {
        return contenu != null; // La case est occupée si elle contient un élément
    }

    public void setOccupee(boolean pos) {
        this.accessible = pos;
    }

    // Vérifie si la case contient un bloc de pierre
    public boolean contientBlocDePierre() {
        return contenu instanceof BlocDePierre;
    }

    // Vérifie si la case contient un pion
    public boolean contientPion() {
        return contenu instanceof Pions;
    }

    // Vérifie si la case contient une flaque d'hémoglobine
    public boolean contientFlaqueHemoglobine() {
        return contenu instanceof FlaqueHemoglobine;
    }

    // Vérifie si la case est une case d'entrée (en bas à droite)
    public boolean estCaseEntree(int lignes, int colonnes) {
        return this.x == lignes - 1 && this.y == colonnes - 1; // Entrée en bas à droite
    }

    // Vérifie si la case est une case de sortie (en haut à gauche)
    public boolean estCaseSortie() {
        return this.x == 0 && this.y == 0; // Sortie en haut à gauche
    }

    @Override
    public String toString() {
        if (!accessible) {
            return "[X]"; // Case inaccessible
        } else if (contenu == null) {
            return "[ ]"; // Case vide
        } else if (contenu instanceof BlocDePierre) {
            return "[B]"; // Bloc de pierre
        } else if (contenu instanceof Pions) {
            return "[P]"; // Pion
        } else if (contenu instanceof FlaqueHemoglobine) {
            return "[H]"; // Flaque d'hémoglobine
        }
        return "[ ]"; // Par défaut, si un contenu non prévu est rencontré
    }
}

package Projet;

public class Monstre {
    private int positionX;
    private int positionY;
    private String orientation; // haut, bas, gauche, droite

    public Monstre(int startX, int startY, String orientationInitiale) {
        this.positionX = startX;
        this.positionY = startY;
        this.orientation = orientationInitiale;
    }

    // Getters et Setters
    public int getPositionX() {
        return positionX;
    }

    public int getPositionY() {
        return positionY;
    }

    public void setPosition(int x, int y) {
        this.positionX = x;
        this.positionY = y;
    }

    public String getOrientation() {
        return orientation;
    }

    public void setOrientation(String orientation) {
        this.orientation = orientation;
    }

    // Tourne le monstre vers un pion cible
    public void tournerVers(Pions cible) {
        if (cible.getX() < positionX) orientation = "haut";
        else if (cible.getX() > positionX) orientation = "bas";
        else if (cible.getY() < positionY) orientation = "gauche";
        else if (cible.getY() > positionY) orientation = "droite";
    }
}
